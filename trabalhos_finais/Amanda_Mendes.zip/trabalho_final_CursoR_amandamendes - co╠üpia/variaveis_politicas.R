### ABRIR PACOTES ----------
library(readxl)
library(dplyr)

### IMPORTAR BASE DE DADOS ----------
base_de_dados <- read_excel("base_de_dados.xlsx")
str(base_de_dados)

### SUCESSSO ----------

presidentes <- unique(base_de_dados$presidente)
vetor_medias_sucesso <- NULL
  
for(presidencia in presidentes) {
  
  # filtrar a base
  base_filtrada <- base_de_dados[base_de_dados$presidente == presidencia, ]
     
  # calcular a media de sucesso para cada presidente
  media_sucesso <- round(mean(base_filtrada$sucesso), digits = 2)
     
  # mensagem
  if (presidencia == "Dilma"){
  print(paste0("A média de sucesso legislativo da presidente ", presidencia, " é de ", media_sucesso, "%"))}
     
  else {
  print(paste0("A média de sucesso legislativo do presidente ", presidencia, " é de ", media_sucesso, "%"))}
     
  # criar vetor de medias
  vetor_medias_sucesso <- c(vetor_medias_sucesso, media_sucesso)
}

### CONFIANÇA ----------

presidentes <- unique(base_de_dados$presidente)
vetor_medias_confianca <- NULL

for(presidencia in presidentes) {
  
  # filtrar a base
  base_filtrada2 <- base_de_dados[base_de_dados$presidente == presidencia, ]
  
  # calcular a media de confiança popular em cada presidente
  media_confianca <- round(mean(base_filtrada2$confianca_no_presidente), digits = 2)
  
  # mensagem
  print(paste0("A média da confianca popular no governo ", presidencia, " é de ", media_confianca, "%"))
  
  # criar vetor de medias
  vetor_medias_confianca <- c(vetor_medias_confianca, media_confianca)
  
}

### DISCIPLINA DA COALIZÃO ----------

presidentes <- unique(base_de_dados$presidente)
vetor_medias_disciplina_coalizao <- NULL

for(presidencia in presidentes) {
  
  # filtrar a base
  base_filtrada <- base_de_dados[base_de_dados$presidente == presidencia, ]

  # calcular a media de disciplina da coalizão de cada presidente
  media_disciplina_coalizao <- (100*(round(mean(base_filtrada$disciplina_coalizao_completa), digits = 4)))
  
  # mensagem
  print(paste0("A média da disciplina da coalizão do governo ", presidencia, " é de ", media_disciplina_coalizao, "%"))
  
  # criar vetor de medias
  vetor_medias_disciplina_coalizao <- c(vetor_medias_disciplina_coalizao, media_disciplina_coalizao)
  
}

### DATA.FRAME DAS VARIÁVEIS POLÍTICAS (CONFIANÇA, SUCESSO E DISICPLINA) ----------

presidente_sucesso_confianca_disciplina <- data.frame(
  presidente = presidentes, 
  media_sucesso_legislativo = vetor_medias_sucesso, 
  media_confianca_popular = vetor_medias_confianca,
  media_disciplina_coalizao = vetor_medias_disciplina_coalizao
)

View(presidente_sucesso_confianca_disciplina)

## Qual presidente conta com maior e menor sucesso legislativo?

# a maior e menor média de sucesso
maior_media_de_sucesso <- max(vetor_medias_sucesso)
menor_media_de_sucesso<- min(vetor_medias_sucesso)

# filtrar base
presidente_maior_sucesso <- filter(presidente_sucesso_confianca_disciplina, media_sucesso_legislativo == maior_media_de_sucesso)
presidente_menor_sucesso <- filter(presidente_sucesso_confianca_disciplina, media_sucesso_legislativo == menor_media_de_sucesso)

# mensagem
print(paste0("O governo ", presidente_maior_sucesso$presidente, ", com ", maior_media_de_sucesso, "%, é o de maior sucesso legislativo"))
print(paste0("O governo ", presidente_menor_sucesso$presidente, ", com ", menor_media_de_sucesso, "%, é o de menor sucesso legislativo"))


## Qual presidente conta com maior e menor confiança popular?

# a maior e menor média de confiaça
maior_media_de_confianca <- max(vetor_medias_confianca)
menor_media_de_confianca <- min(vetor_medias_confianca)

# filtrar base
presidente_maior_confianca <- filter(presidente_sucesso_confianca_disciplina, media_confianca_popular == maior_media_de_confianca)
presidente_menor_confianca <- filter(presidente_sucesso_confianca_disciplina, media_confianca_popular == menor_media_de_confianca)

# mensagem
print(paste0("O governo ", presidente_maior_confianca$presidente, ", com ", maior_media_de_confianca, "%, é o com maior confiança popular"))
print(paste0("O governo ", presidente_menor_confianca$presidente, ", com ", menor_media_de_confianca, "%, é o com menor confiança popular"))

## Qual presidente conta com a coalizão mais disciplinada e com a menos disicplinada? 

# a maior e menor média de disciplina da coalizão
maior_media_de_disciplina <- max(vetor_medias_disciplina_coalizao)
menor_media_de_disciplina <- min(vetor_medias_disciplina_coalizao)

# filtrar base
presidente_coal_mais_disciplinada <- filter(presidente_sucesso_confianca_disciplina, media_disciplina_coalizao == maior_media_de_disciplina)
presidente_coal_menos_disciplinada <- filter(presidente_sucesso_confianca_disciplina, media_disciplina_coalizao == menor_media_de_disciplina)

# mensagem
print(paste0("O governo ", presidente_coal_mais_disciplinada$presidente, ", com ", maior_media_de_disciplina, "%, contou com a coalizão mais disciplinada no Congresso"))
print(paste0("O governo ", presidente_coal_menos_disciplinada$presidente, ", com ", menor_media_de_disciplina, "%, enfrentou a coalizão menos disciplinada no Congresso"))
