### INSTALAR PACTOES ----------

# para ler planilhas do excel
install.packages("readxl")

# para acessar funções do pacote {dplyr}
install.packages("dplyr")