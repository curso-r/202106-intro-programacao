### ABRIR PACOTES ----------
library(readxl)
library(dplyr)

### IMPORTAR BASE DE DADOS ----------
base_de_dados <- read_excel("base_de_dados.xlsx")
View(base_de_dados)
str(base_de_dados)

### ANO DOS GOVERNOS DA AMOSTRA ----------

presidentes <- unique(base_de_dados$presidente)
vetor_ano_minimo <- NULL
vetor_ano_maximo <- NULL

for(presidencia in presidentes){
  
  # filtrar base
  base_filtrada <- filter(base_de_dados, base_de_dados$presidente == presidencia)
  
  # definir o ano inical e final do governo na amostra
  ano_minimo <- min(base_filtrada$ano_de_apresentacao)
  ano_maximo <- max(base_filtrada$ano_de_apresentacao)
  
  # criar vetores com os anos de início e fim de cada governo na amostra
  vetor_ano_minimo <- c(vetor_ano_minimo, ano_minimo)
  vetor_ano_maximo <- c(vetor_ano_maximo, ano_maximo)
  
  # mensagem
  print(paste0("Nesta amostra, o governo ", presidencia, " vai de ", ano_minimo, " até ", ano_maximo, "."))
}

### PROJETOS APRESENTADOS ----------

presidentes <- unique(base_de_dados$presidente)
vetor_soma_projetos <- NULL
vetor_media_projetos <- NULL

for(presidencia in presidentes) {
  
  # filtrar a base
  base_filtrada <- filter(base_de_dados, base_de_dados$presidente == presidencia)
  
  # calcular a soma total dos projetos apresentados por cada presidente
  soma_projetos <- sum(base_filtrada$projetos_apresentados, na.rm = TRUE) 
  
  # criar vetor da soma de projetos apresentados por presidente                   
  vetor_soma_projetos <- c(vetor_soma_projetos, soma_projetos)
  
  # calcular a média de projetos apresentados por mês para cada presidente
  media_projetos <- mean(base_filtrada$projetos_apresentados, na.rm = TRUE) %>%
    round(digits = 2)
  
  # criar vetor da média de projetos apresentados por mês por presidente
  vetor_media_projetos <- c(vetor_media_projetos, media_projetos)
  
  # mensagem
  print(paste0("O governo ", presidencia, " apresentou ", soma_projetos, 
               " projetos ao Congresso Federal, com uma média mensal de ",
               media_projetos, " iniciativas legislativas."))
  
}

## Presidentes com mais e com menos inciativa legislativa
  
# data.Frame com as somas dos projetos apresentados por presidente
projetos_presidentes <- data.frame(presidente = presidentes, total_projetos = vetor_soma_projetos) 
View(projetos_presidentes)

# presidente com a maior e a menor quantidade de projetos apresentados 
presidente_mais_iniciativa <- filter(projetos_presidentes, total_projetos == max(projetos_presidentes$total_projetos))

presidente_menos_iniciativa <- filter(projetos_presidentes, total_projetos == min(projetos_presidentes$total_projetos))

# mensagem
print(paste("O governo", presidente_mais_iniciativa$presidente, "foi o que apresentou mais projetos."))
print(paste("O governo", presidente_menos_iniciativa$presidente, "foi o que apresentou menos projetos."))

