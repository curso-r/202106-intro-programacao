### ABRIR PACOTES ----------
library(readxl)
library(dplyr)

# IMPORTAR BASE DE DADOS ----------

base_de_dados <- read_excel("base_de_dados.xlsx")
str(base_de_dados)

### DESEMPREGO ----------

presidentes <- unique(base_de_dados$presidente)
vetor_medias_desemprego <- NULL

for(presidencia in presidentes) {
  
  # filtrar base
  base_filtrada <- filter(base_de_dados, presidente == presidencia)
  
  # calcular a media de sucesso para cada presidente
  
  media_desemprego <- mean(base_filtrada$taxa_de_desemprego__sa, na.rm = TRUE) %>%
                      round (digits = 2)
  
  # mensagem: media de cada governo
  print(paste0("A média de desemprego no governo ", presidencia, " é de ", media_desemprego, "%"))
  
  # criar vetor de medias
  vetor_medias_desemprego <- c(vetor_medias_desemprego, media_desemprego)
  
}

### ÍNDICE DE PREÇOS AO CONSUMIDOR AMPLO ----------

presidentes <- unique(base_de_dados$presidente)
vetor_medias_ipca <- NULL

for(presidencia in presidentes) {
  
  # filtrar base
  base_filtrada <- filter(base_de_dados, presidente == presidencia)
  
  # calcular a media de sucesso para cada presidente
  
  media_ipca <- mean(base_filtrada$ipca_sa_x12, na.rm = TRUE) %>%
                round (digits = 2)
  
  # mensagem: media de cada governo
  print(paste0("A média do ipca no governo ", presidencia, " é de ", media_ipca, "%"))
  
  # criar vetor de medias
  vetor_medias_ipca <- c(vetor_medias_ipca, media_ipca)
  
}

### DATA.FRAME DAS VARIÁVEIS ECONÔMICAS (DESEMPREGO E IPCA)----------

base_variaveis_economicas <- data.frame(
  presidentes, 
  media_desemprego = vetor_medias_desemprego, 
  media_ipca = vetor_medias_ipca
)

View(base_variaveis_economicas)

## Governos petistas

# filtrar base por presidente (opção para usar mais funções)
base_lula <- filter(base_variaveis_economicas, presidentes == "Lula" | presidentes == "Lula II",)
base_dilma <- filter(base_variaveis_economicas, presidentes == "Dilma",)

# juntar base para partido
base_variaveis_economicas_pt <- bind_rows(base_lula, base_dilma)

# calcular médias
media_desemprego_pt <- mean(base_variaveis_economicas_pt$media_desemprego) %>%
  round(digits = 2)
media_ipca_pt <- mean(base_variaveis_economicas_pt$media_ipca) %>%
  round(digits = 2)

# imprimir mensagem
print(paste0("A média da taxa de desemprego nos governos do Partido dos Trabalhadores foi de ", media_desemprego_pt, "%"))
print(paste0("A média da taxa do Índice de Preços ao Consumidor Amplo nos governos do Partido dos Trabalhadores foi de ", media_ipca_pt, "%"))

## Governos tucanos

# filtrar base
base_variaveis_economicas_psdb <- filter(base_variaveis_economicas, presidentes == "FHC" | presidentes == "FHC II")

# calcular médias
media_desemprego_psdb <- mean(base_variaveis_economicas_psdb$media_desemprego) %>%
  round(digits = 2)
media_ipca_psdb <- mean(base_variaveis_economicas_psdb$media_ipca) %>%
  round(digits = 2)

# imprimir mensagem
print(paste0("A média da taxa de desemprego nos governos do Partido da Social Democracia Brasileira foi de ", media_desemprego_psdb, "%"))
print(paste0("A média da taxa do Índice de Preços ao Consumidor Amplo nos governos do Partido da Social Democracia Brasileira foi de ", media_ipca_psdb, "%"))

## Comparando PSDB e PT

# desemprego
if(media_desemprego_pt > media_desemprego_psdb) {
  print(paste0("Portanto, os governos petistas apresentaram uma média na taxa de desemprego maior do que os governos tucanos"))
} else{ 
  print(paste0("Portanto, os governos tucanos apresentaram uma média na taxa de desemprego maior do que os governos petistas "))
}

# ipca
if(media_ipca_pt > media_ipca_psdb) {
  print(paste0("Portanto, os governos petistas apresentaram uma média no IPCA maior do que os governos tucanos"))
} else{ 
  print(paste0("Portando, os governos tucanos apresentaram uma média no IPCA maior do que os governos petistas "))
}
