# pacotes -----------------------------------------------------------------
library(tidyverse)
library(readxl)
library(lubridate)
library(BatchGetSymbols)
library(crayon)
library(magrittr)

# funções de print ----------------------------------------------------------

reais <- function(x) { 
  if (x >= 0) {
  x %>% 
    round(digits = 2) %>% 
    format(big.mark = ".", 
           decimal.mark = ",", 
           nsmall = 2, 
           scientific = FALSE
           ) %>%  
    paste0("R$", .)
  } else {
  x %>% 
    abs() %>% 
    round(digits = 2) %>% 
    format(big.mark = ".", 
           decimal.mark = ",", 
           nsmall = 2, 
           scientific = FALSE
           ) %>%  
    paste0("- R$", .)
  }
}

reais_abs <- function(x) { 
    x %>% 
      abs() %>% 
      round(digits = 2) %>% 
      format(big.mark = ".", 
             decimal.mark = ",", 
             nsmall = 2, 
             scientific = FALSE
             ) %>%  
      paste0("R$", .)
}

reais_cor <- function(x) { 
x %>% 
  reais_abs() %>% 
  bold() %>%
  {if_else(x > 0, green(.), red(.))}
}

porcento <- function(x, precisao = 2) {
  (x * 100) %>% 
    round(digits = precisao) %>% 
    format(decimal.mark = ",",
           scientific = FALSE,
           nsmall = 0) %>% 
    paste0("%")
  }



# cat(sep = "\n",
#   reais(20.643),
#   reais(-10.235),
#   reais_abs(-40.3),
#   reais_cor(25),
#   reais_cor(-100000.355)
#   )



# mais funções -----------------------------------------------------------

as_ticker <- function(ativo) {
  paste0(ativo, ".SA", sep = "")
  }

# cat(
#   as_ticker("MGLU3")
#   )

as_resultado <- function(resultado) {
  if_else(resultado >= 0, "lucro", "prejuízo")
}

# cat(
#  "Houve um",
#  as_resultado(25),
#  "de",
#  reais_cor(25)
# )

# objetos úteis ----------------------------------------------------------- 

aliquotas <- tribble(
  ~classe, ~aliquota,
  "ACOES", .15,
  "ETF", .15,
  "FII", .2)

# e inúteis

mensagem_lucro <- "Uau! Já pensou em vender cursos de day trade?"
mensagem_prejuizo <- paste("Parece que sua estratégia não tá dando muito certo...",
                           "Já pensou em vender cursos de day trade?")


# printando data em português ---------------------------------------------

meses <- c("janeiro", "fevereiro", "março", "abril", "maio", "junho",
           "julho", "agosto", "setembro", "outubro", "novembro", "dezembro")

data <- function(x) {
 paste(day(x), "de",
       meses[month(x)], "de",
       year(x))
}


# e uma função pra deixar as coisas azuis ---------------------------------

strong <- function(x) {
  blue(bold(x))
  }

