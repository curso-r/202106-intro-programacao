# SETUP  ------------------------------------------------------------------

# Dentro deste arquivo, estão todos os pacotes necessários, bem como algumas
# funções e objetos que nos serão úteis mais pra frente.
source("scripts/00-setup.R")

# MENSAGEM INICIAL --------------------------------------------------------

cat(sep = "\n",
    "Olá! Vou analisar sua carteira de ações a partir de todas as movimentações que você já realizou.",
    "Vou te mostrar o que você tem no seu portfólio, além de calcular a rentabilidade realizada e não realizada.",
    bold("Vamos começar?")
)

# IMPORTAR TABELA -----------------------------------------------------

movimentacoes_raw <- read_excel("inputs/movimentacoes.xlsx")

# ...e dar um tapinha!
movimentacoes <- movimentacoes_raw %>%
  arrange(data) %>% 
  mutate(operacao = if_else(quantidade > 0, "C", "V")) %>% 
  mutate(subtotal = quantidade * preco)


cat( sep = "\n",
"Tabela de movimentações importada com sucesso.",
paste("Serão analisadas", 
      strong(nrow(movimentacoes)), 
      "operações de compra e venda de",
      strong(length(unique(movimentacoes$ativo))),
      "ativos diferentes,"), 
paste0("realizadas do dia ",
      strong(data(movimentacoes$data[1])),
      " até o dia ",
      strong(data(movimentacoes$data[nrow(movimentacoes)])), ".")
   )

# CRIAR LISTA COM ATIVOS ("CARTEIRA") ----------------------

lista_ativos <- unique(movimentacoes$ativo)
carteira <- list()

for (x in seq_along(lista_ativos)) {
  carteira[[x]] <- movimentacoes %>%
    filter(ativo == lista_ativos[x])
  names(carteira)[[x]] <- lista_ativos[x]
}

cat("Acabei de separar as movimentações por ativos e juntar tudo numa lista.")

# CALCULAR PREÇO MÉDIO DE COMPRA ---------------------------------------

cat(sep = "\n",
  paste0("Agora, vou calcular o ", bold("preço médio de compra"), " de cada ativo para cada uma das movimentações."),
  "Lembrando que, a cada nova compra, o preço médio é atualizado. Nas vendas, o preço médio se mantém."
  )

# loop pra fazer isso em todas as subcarteiras
for (sub in seq_along(carteira)) {
  # loop do estoque
  carteira[[sub]]$estoque <- NA
  for (op in 1:nrow(carteira[[sub]])) {
    carteira[[sub]]$estoque[op] <- sum(carteira[[sub]]$quantidade[1:op])
  }
  
  # loop do preço médio
  carteira[[sub]]$preco_medio <- NA
  carteira[[sub]]$preco_medio[1] <- carteira[[sub]]$preco[1]
  
  if (nrow(carteira[[sub]]) > 1) {
    for (op in 2:nrow(carteira[[sub]])) {
      if (carteira[[sub]]$operacao[op] == "C") {
        # se for compra...
        carteira[[sub]]$preco_medio[op] <-
          (
            carteira[[sub]]$preco[op] *
              carteira[[sub]]$quantidade[op] +
              carteira[[sub]]$preco_medio[op - 1] *
              carteira[[sub]]$estoque[op - 1]
          ) /
          carteira[[sub]]$estoque[op]
      } else {
        # se for venda...
        carteira[[sub]]$preco_medio[op] <-
          carteira[[sub]]$preco_medio[op - 1] # preço médio se mantém
      }
    }
  }
  
}

cat(sep = "\n",
 "Sucesso!" ,
 paste0("Agora, na nossa ", bold("carteira"), ", temos o preço médio de compra de cada ativo após cada operação."),
 "Isso vai nos ajudar a calcular a rentabilidade dos seus investimentos.",
 paste0("Para isso, vou juntar tudo numa tabela só de novo, que vou chamar de ", bold("movimentacoes_turbo"), ".")
)


# MOVIMENTAÇÕES TURBO (com preço médio) ------------------------

movimentacoes_turbo <- map_dfr(carteira, bind_rows)

carteira_atual <- 
movimentacoes_turbo %>% 
  group_by(classe, ativo) %>% 
  summarise(data = max(data), estoque = last(estoque),
            preco_medio = last(preco_medio)) %>% 
  filter(estoque != 0) %>% 
  select(-data)

cat(sep = "\n",
  paste0("OK. Tudo junto. Também fiz uma tabelinha nova, a ", bold("carteira_atual"), "."),
  "É um resumo de tudo que você tem em carteira no momento, e quanto você pagou em média por cada ativo.",
  "Peço licença pra abrir essa tabela no seu RStudio..."
  )

View(carteira_atual)


# Criando um vetor somente com os ativos em carteira, pra pegar os preços atuais.
lista_ativos_portfolio <- carteira_atual$ativo


# IMPOSTO DE RENDA (E RENTABILIDADE REALIZADA) --------------------------------------

cat(sep = "\n",
  "Mas, calma! Antes de calcular o valor presente das coisas, vamos olhar um pouco para o passado.",
  paste0("Ou seja: filtrar todas as vendas da tabela pra calcular o que você teve de ", 
         green(bold("lucro")),
         " ou ",
         red(bold("prejuízo"))),
  paste0("com cada uma delas, e também o quanto de ", bold("imposto de renda"), " você pagou pelos rendimentos."),
  paste0("...Ou deveria ter pago, né? ", bold("Corre aqui, leão!!!"))
  )

# uma tabela só com as vendas
movimentacoes_vendas <- movimentacoes_turbo %>% 
  filter(operacao == "V") %>% 
  arrange(classe, data) %>% 
  mutate(ano = year(data), mes = month(data)) %>% 
  select(ano, data, mes, everything()) %>% 
  mutate(custo_operacao = preco_medio * quantidade * -1) %>% 
  mutate(subtotal = -subtotal) %>% 
  mutate(resultado_operacao = subtotal - custo_operacao) 

# e outra agrupada e resumida por mês (porque o IR se paga mensalmente)
vendas_por_mes <- movimentacoes_vendas %>% 
  select(ano, mes, classe, subtotal, resultado_operacao) %>% 
  group_by(ano, mes, classe) %>% 
  summarise(ano = last(ano),
            mes = last(mes),
            classe = last(classe),
            total_vendido = sum(subtotal),
            resultado_mes = sum(resultado_operacao)
  ) %>% 
  arrange(classe, ano, mes)

cat(
  sep = "\n",
  paste0("Prooonto. Todas as vendas separadas em ", bold("movimentacoes_vendas"), ","),
  paste0("e agrupadas por mês em ", bold("vendas_por_mes"), ". Como você não é o Warren Buffet,"),
  "deve ter vendido com prejuízo algumas vezes. Acontece nas melhores famílias...",
  "Mas tem um lado bom: os prejuízos acumulados, que vou calcular agora, podem ser abatidos do imposto de renda!",
  "Sobra mais dinheiro pra você torrar tentando fazer day trade."
  )

# PREJUÍZO ACUMULADO ------------------------------------------------------
classes <- unique(vendas_por_mes$classe) %>% sort()
vendas_por_mes$prejuizo_acumulado <- 0
vendas_por_mes$valor_tributavel <- 0
vendas_por_mes_IR <- NULL


for (x in classes) {
  vendas_por_classe <- vendas_por_mes %>%
    filter(classe == x)
  
  
  for (i in 1:nrow(vendas_por_classe)) {
    if (i == 1) {
      vendas_por_classe$prejuizo_acumulado[i] <-
        min(0, vendas_por_classe$resultado_mes[i])
    } else {
      vendas_por_classe$prejuizo_acumulado[i] <- min(0,
                                                     vendas_por_classe$resultado_mes[i] +
                                                       vendas_por_classe$prejuizo_acumulado[i -
                                                                                              1])
    }
  }
  
  if (x == "ACOES") {
    vendas_por_classe <- vendas_por_classe %>%
      mutate(valor_tributavel = if_else(total_vendido > 20000,
                                        if_else(
                                          resultado_mes < 0,
                                          0,
                                          max(resultado_mes + prejuizo_acumulado, 0)
                                        ),
                                        0))
  }
  
  else {
    vendas_por_classe <- vendas_por_classe %>%
      mutate(valor_tributavel = if_else(
        resultado_mes < 0,
        0,
        max(resultado_mes + prejuizo_acumulado, 0)
      ))
  }
  
  
  vendas_por_mes_IR <-
    bind_rows(vendas_por_mes_IR, vendas_por_classe)
}

vendas_por_mes_IR <- vendas_por_mes_IR %>% 
  left_join(aliquotas) %>% 
  mutate(imposto_a_pagar = valor_tributavel * aliquota)

cat(sep = "\n",
  "Imposto de renda calculadíssimo!",
  "Essa é uma tabela que vou pedir licença pra abrir no seu RStudio também,",
  "porque vai ser útil pra você usar na sua declaração anual."
  )

view(vendas_por_mes_IR)

IR_ano_anterior <- 
vendas_por_mes_IR %>% 
  filter(ano == year(Sys.Date()) - 1)

write_rds(IR_ano_anterior, paste0("outputs/", year(Sys.Date()) - 1, "-IR.rds"))

IR_mes_anterior <- 
  vendas_por_mes_IR %>% 
  filter(ano == rollback(Sys.Date()) %>% year(),
         mes == rollback(Sys.Date()) %>% month())

write_rds(IR_mes_anterior, paste0("outputs/", 
                                  rollback(Sys.Date()) %>% year(), "-", 
                                  rollback(Sys.Date()) %>% month(),
                                  "-IR.rds"))

cat(sep = "\n",
  paste0("Acabei de salvar pra você uma tabela com tudo que você precisa para declarar o IRPF ", strong(year(Sys.Date())), "."),
  paste0("Também salvei uma tabela com as informações sobre o imposto devido pelas operações realizadas no mês passado,"),
  paste0(meses[rollback(Sys.Date()) %>% month()] %>% strong(), " de ", rollback(Sys.Date()) %>% year() %>% strong(),
         ". Está tudo na pasta ", bold("outputs"), ", ok?")
  )


# apagar essas tabelas intermediárias
rm(vendas_por_mes)
rm(vendas_por_classe)


cat(sep = "\n",
  paste0("Resolvidas as pendências com o Leão, vamos ao que importa: calcular a ", 
         bold("rentabilidade realizada"), ","),
  paste0("isto é, quanto você teve de ", "lucro" %>% bold() %>% green(), " ou ", "prejuízo" %>% bold() %>% red(), " naquilo que já vendeu.")
  )

total_realizado_bruto <- sum(vendas_por_mes_IR$resultado_mes)
total_imposto_pago <- sum(vendas_por_mes_IR$imposto_a_pagar)
total_realizado_liquido <- total_realizado_bruto - total_imposto_pago

cat(sep = "\n",
  "Eis o resultado!" %>% bold(),
  paste(
    if_else(total_realizado_liquido > 0,
            "Lucro líquido:",
            "Prejuízo:"),
    reais_cor(total_realizado_liquido)
    )
  )

# faltou o custo das vendas!!!! mas não é um problema para nós...
custo_vendas <-
  movimentacoes_vendas %>% 
  select(quantidade, preco_medio) %>% 
  mutate(cpv = quantidade * preco_medio) %>% 
  pull(cpv) %>% 
  sum()

custo_vendas <- - custo_vendas

# RENTABILIDADE NÃO-REALIZADA ----------------------------------------

cat(sep = "\n",
  "Pagou a conta do wi-fi? Vamos precisar dele para pegar os preços atuais dos ativos."
  )

# catando preços online...
precos_atuais <- BatchGetSymbols(
  tickers = as_ticker(lista_ativos_portfolio),
  first.date = Sys.Date() - 5, # o -5 aqui é pra tentar sempre pegar pelo menos um dia útil
  last.date = Sys.Date())$df.tickers %>%
  group_by(ticker) %>% 
  summarise(ticker = last(ticker), price.close = last(price.close))

# salvando num arquivo
write_rds(
  precos_atuais,
  paste0(
    "outputs/",
    Sys.Date(),
    "-precos.rds"
    )
  )
cat(sep = "\n",
  "Prontinho. Guardei tudo lá nos outputs, também, caso você queira calcular de novo no futuro com os preços de hoje.",
  "Mas aí se vira pra editar o código, tá?"
  )

# botando lá na carteira atual
carteira_atual <- carteira_atual %>%  
  mutate(ticker = as_ticker(ativo)) %>% 
  left_join(precos_atuais) %>% 
  rename(cotacao_atual = price.close) %>% 
  select(-ticker)


# VALOR ATUAL DA CARTEIRA --------------------------------
carteira_atual <- carteira_atual %>% 
  mutate(valor_atual = estoque * cotacao_atual,
         valorizacao = valor_atual - preco_medio * estoque,
         rentabilidade = valorizacao / (preco_medio * estoque))


cat(sep = "\n",
    "Valorização de cada ativo bonitinha na tabela agora, pra gente calcular a",
    paste0("rentabilidade" %>% bold(), " ainda não realizada da carteira.")
    )

# vamos calcular o lucro/prejuízo ainda não realizados...
valor_carteira_atual <- sum(carteira_atual$estoque *
                                    carteira_atual$cotacao_atual)
custo_carteira_atual <- sum(carteira_atual$estoque *
                                    carteira_atual$preco_medio)

# esta é a valorização ou desvalorização da carteira, segundo os preços atuais
resultado_carteira_atual <-
  valor_carteira_atual - custo_carteira_atual

# e agora juntar tudo!
resultado_total <- resultado_carteira_atual + total_realizado_liquido
custo_total <- custo_carteira_atual + custo_vendas

rentabilidade_total <- resultado_total / custo_total

cat(sep = "\n",
  "Nem acredito. Já calculei tudo!!! Está preparado para o resultado?",
  paste0("Manda a ver no ", "Ctrl + Enter" %>% bold(), ".")
  )

# COMUNICANDO E SALVANDO RESULTADOS -----------------------------------------

cat(sep = "\n",
     paste0(
  "Você possui ",
  strong(reais(valor_carteira_atual)),
  " em ações, ETFs e/ou Fundos Imobiliários, que lhe custaram ",
  strong(reais(custo_carteira_atual)), "."),
  paste0(
  "Isso representa um ",
  as_resultado(resultado_carteira_atual),
  " de ",
  reais_cor(resultado_carteira_atual), ". Considerando tudo que você já vendeu,"),
  paste0(
  "a sua carteira gerou, até o dia ",
  data(Sys.Date()) %>% strong(), ", um ",
  as_resultado(resultado_total), " de ",
  reais_cor(resultado_total), "."), 
  paste0(
  "Uma rentabilidade líquida de ",
  bold(porcento(rentabilidade_total,1)) %>% 
    {if_else(
      rentabilidade_total > 0,
      green(.),
      red(.))},
  "!"),
  ifelse(resultado_total > 0, mensagem_lucro, mensagem_prejuizo)
)

cat(sep = "\n",
  "Ufa... Última coisinha agora. Vou salvar tudo isso num documento de texto pra você."
  )

cat(
    file = paste0("outputs/", Sys.Date(), "-resumo-carteira.txt"),
    sep = "\n",
    paste0("Data: ",
           data(Sys.Date())),
    "",
    paste0("Valor bruto da carteira: ", reais(valor_carteira_atual)),
    paste0("Custo da carteira: ", reais(custo_carteira_atual)),
    paste0("Total do ", as_resultado(rentabilidade_total), " realizado: ", reais(total_realizado_liquido)),
    paste0("Total do imposto pago: ", reais(total_imposto_pago)),
    paste0("Rentabilidade: ", porcento(rentabilidade_total)),
    "",
    "Ativos em carteira:",
    lista_ativos_portfolio
)

cat(
  paste0("Feito! Obrigado pela companhia e bons investimentos! ", strong(":)"))
  )
